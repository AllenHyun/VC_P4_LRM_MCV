# VCP4 > Version final - YOLOv11
https://universe.roboflow.com/vcp4/vcp4-7iw19

Provided by a Roboflow user
License: CC BY 4.0

